package com.example.chatapplication.listeners;

import com.example.chatapplication.models.User;

public interface ConversionListener {

    void onConversionClicked(User user);
}
