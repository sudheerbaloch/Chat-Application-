package com.example.chatapplication.listeners;

import com.example.chatapplication.models.User;

public interface UserListener {

    void onUserClicked(User user);
}
